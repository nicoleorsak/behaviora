import WaitlistForm from "./waitlist-form";

export default function Home() {
  return (
    <>
      <nav>
        <div className="logo">Behaviora</div>
        <a href="#waitlist" className="nav-cta">
          Join Waitlist
        </a>
      </nav>

      <section className="hero">
        <div className="hero-content">
          <div className="hero-badge">
            <span className="dot" />
            Coming Soon
          </div>
          <h1>
            Predict what works
            <br />
            <span className="gradient">before you build it</span>
          </h1>
          <p className="hero-sub">
            AI coding tools made building 10x faster.
            <br />
            Behaviora makes shipping 10x smarter.
          </p>
          <p className="hero-desc">
            Simulate user behavior before engineering writes a line of code. See
            which features will move metrics, understand why, and ship with
            confidence.
          </p>
          <div className="hero-actions">
            <a href="#waitlist" className="btn-primary">
              Join the Waitlist &rarr;
            </a>
            <a href="#problem" className="btn-ghost">
              See How It Works &darr;
            </a>
          </div>
        </div>
      </section>

      <section className="problem" id="problem">
        <div className="container">
          <div className="problem-header">
            <p className="section-label">The Product Velocity Paradox</p>
            <h2 className="section-headline">
              70% of features fail.
              <br />
              AI made building faster&mdash;not smarter.
            </h2>
            <p className="section-sub">
              Teams ship more than ever, but most features still don&rsquo;t
              move the needle. The bottleneck has shifted.
            </p>
          </div>
          <div className="problem-grid">
            <div className="problem-card">
              <p className="card-step">The Old Bottleneck</p>
              <p className="card-question">&ldquo;Can we build it?&rdquo;</p>
              <p className="card-text">
                Engineering time was the constraint. Features took weeks to
                build. Shipping was slow, and capacity dictated what got done.
              </p>
            </div>
            <div className="problem-card">
              <p className="card-step">The New Reality</p>
              <p className="card-question">
                &ldquo;Should we build it?&rdquo;
              </p>
              <p className="card-text">
                AI tools made building 10x faster. But speed didn&rsquo;t solve
                the real problem&mdash;most features still don&rsquo;t move
                metrics.
              </p>
            </div>
            <div className="problem-card highlight">
              <p className="card-step">The New Bottleneck</p>
              <p className="card-question">
                &ldquo;Will it actually work?&rdquo;
              </p>
              <p className="card-text">
                Teams ship faster but validate less. By the time A/B tests
                reveal failure, weeks of effort have already been wasted.
              </p>
            </div>
          </div>
          <div className="transition-statement">
            <p>
              There&rsquo;s a better way.{" "}
              <span>Test in simulation, not production.</span>
            </p>
          </div>
        </div>
      </section>

      <section className="cta-section" id="waitlist">
        <div className="container">
          <div className="cta-inner">
            <p className="section-label">Ready to Ship Smarter?</p>
            <h2 className="section-headline">
              Stop guessing.
              <br />
              Start predicting.
            </h2>
            <WaitlistForm />
          </div>
        </div>
      </section>

      <footer>
        <div className="footer-logo">Behaviora</div>
        <p>&copy; 2025 Behaviora</p>
      </footer>
    </>
  );
}
