"use client";

import { useState, type FormEvent, type KeyboardEvent } from "react";

export default function WaitlistForm() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(false);

  function handleSubmit(e?: FormEvent) {
    e?.preventDefault();
    if (!email || !email.includes("@") || !email.includes(".")) {
      setError(true);
      return;
    }
    setSubmitted(true);
  }

  function handleKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") handleSubmit();
    setError(false);
  }

  if (submitted) {
    return (
      <div className="success-msg">
        You\u2019re on the list! We\u2019ll be in touch soon.
      </div>
    );
  }

  return (
    <>
      <div className="waitlist-form">
        <input
          type="email"
          placeholder="you@company.com"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            setError(false);
          }}
          onKeyDown={handleKeyDown}
          style={
            error
              ? {
                  borderColor: "#ff6b6b",
                  boxShadow: "0 0 0 3px rgba(255,107,107,0.1)",
                }
              : undefined
          }
        />
        <button onClick={() => handleSubmit()}>Join Waitlist</button>
      </div>
      <p className="form-note">
        Be first in line for early access. No spam, ever.
      </p>
    </>
  );
}
